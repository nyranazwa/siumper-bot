"""Unit test logika ketersediaan barang/ruangan."""

from datetime import datetime

from bot.services.ketersediaan import cek_ketersediaan, saran_waktu


def _pinjam(jenis, item, jumlah, mulai, selesai, status="Disetujui"):
    return {
        "jenis": jenis, "item": item, "jumlah": str(jumlah),
        "tanggal_mulai": mulai, "tanggal_selesai": selesai, "status": status,
    }


DATA = [
    _pinjam("barang", "PRY", 3, "2026-10-20 08:00", "2026-10-20 12:00"),
    _pinjam("barang", "SPK", 2, "2026-10-20 09:00", "2026-10-20 11:00", status="Ditolak"),
    _pinjam("ruangan", "AULA", 1, "2026-10-21 13:00", "2026-10-21 16:00", status="Menunggu Verifikasi"),
]


def jam(tgl, j):
    return datetime(2026, 10, tgl, j, 0)


def test_barang_stok_cukup():
    hasil = cek_ketersediaan("barang", "PRY", jam(20, 9), jam(20, 10), DATA, stok_total=5, jumlah=2)
    assert hasil.tersedia and hasil.sisa == 2


def test_barang_stok_kurang():
    hasil = cek_ketersediaan("barang", "PRY", jam(20, 9), jam(20, 10), DATA, stok_total=5, jumlah=3)
    assert not hasil.tersedia and hasil.sisa == 2


def test_status_ditolak_diabaikan():
    hasil = cek_ketersediaan("barang", "SPK", jam(20, 9), jam(20, 10), DATA, stok_total=4, jumlah=4)
    assert hasil.tersedia and hasil.sisa == 4


def test_waktu_bersentuhan_tidak_bentrok():
    hasil = cek_ketersediaan("barang", "PRY", jam(20, 12), jam(20, 14), DATA, stok_total=5, jumlah=5)
    assert hasil.tersedia


def test_ruangan_bentrok():
    hasil = cek_ketersediaan("ruangan", "AULA", jam(21, 14), jam(21, 15), DATA)
    assert not hasil.tersedia
    assert saran_waktu(hasil.bentrok) == jam(21, 16)


def test_ruangan_lain_tidak_terpengaruh():
    hasil = cek_ketersediaan("ruangan", "RA", jam(21, 14), jam(21, 15), DATA)
    assert hasil.tersedia
