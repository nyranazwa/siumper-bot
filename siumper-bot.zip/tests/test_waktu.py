"""Unit test parsing tanggal dan jam."""

from datetime import datetime

import pytest

from bot.utils.waktu import FormatWaktuSalah, parse_rentang, parse_waktu


def test_parse_rentang_format_standar():
    mulai, selesai = parse_rentang("20-10-2026 08:00-12:00")
    assert mulai == datetime(2026, 10, 20, 8, 0)
    assert selesai == datetime(2026, 10, 20, 12, 0)


def test_parse_rentang_format_alternatif():
    mulai, selesai = parse_rentang("20/10/2026 8.00 sampai 12.30")
    assert mulai == datetime(2026, 10, 20, 8, 0)
    assert selesai == datetime(2026, 10, 20, 12, 30)


@pytest.mark.parametrize("teks", ["besok jam 8", "2026-10-20 08:00-12:00", "20-10-2026", ""])
def test_parse_rentang_format_salah(teks):
    with pytest.raises(FormatWaktuSalah):
        parse_rentang(teks)


def test_parse_rentang_jam_selesai_sebelum_mulai():
    with pytest.raises(FormatWaktuSalah):
        parse_rentang("20-10-2026 12:00-08:00")


def test_parse_rentang_tanggal_tidak_ada():
    with pytest.raises(FormatWaktuSalah):
        parse_rentang("31-02-2026 08:00-10:00")


def test_parse_waktu():
    assert parse_waktu("20-10-2026 08:00") == datetime(2026, 10, 20, 8, 0)
    with pytest.raises(FormatWaktuSalah):
        parse_waktu("20-10-2026 25:00")
