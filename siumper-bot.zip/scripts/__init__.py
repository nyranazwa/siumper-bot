"""Skrip utilitas (seed data, cek koneksi)."""
