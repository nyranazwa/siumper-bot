"""Mengisi Google Sheets dengan data contoh untuk prototipe SiUmper.

Cara menjalankan (dari folder root proyek):
    python -m scripts.seed_data          # akan meminta konfirmasi
    python -m scripts.seed_data --yes    # tanpa konfirmasi

PERINGATAN: isi sheet Barang, Ruangan, DBR, dan Peminjaman akan DITIMPA.
"""

import argparse
import sys
from datetime import datetime, timedelta

from bot.config import ConfigError, muat_config_sheets
from bot.constants import (
    FORMAT_WAKTU,
    JENIS_BARANG,
    JENIS_RUANGAN,
    SHEET_BARANG,
    SHEET_DBR,
    SHEET_PEMINJAMAN,
    SHEET_RUANGAN,
    STATUS_DISETUJUI,
    STATUS_DITOLAK,
    STATUS_MENUNGGU,
)
from bot.services.sheets import SheetsError, SheetsService

# Prefix kode stiker inventaris UPI Kampus Tasikmalaya (contoh)
PREFIX_STIKER = "UPITSM"

# ---------------------------------------------------------------------
# Data master
# ---------------------------------------------------------------------
# kode_ruangan, nama_ruangan, kapasitas
RUANGAN = [
    ["AULA", "Aula Kampus", 200],
    ["RA", "Ruangan A", 40],
    ["RB", "Ruangan B", 40],
    ["LABKOM", "Lab Komputer", 35],
    ["SEMINAR", "Ruang Seminar", 80],
]

# kode_barang, nama_barang, daftar ruangan asal tiap unit (jumlah unit = stok_total)
BARANG = [
    ["PRY", "Proyektor", ["Ruangan A", "Ruangan B", "Ruang Seminar", "Gudang UMPER", "Gudang UMPER"]],
    ["TV", "Televisi LED 43 inci", ["Ruangan A", "Aula Kampus"]],
    ["SPK", "Speaker Portable", ["Aula Kampus", "Aula Kampus", "Gudang UMPER", "Gudang UMPER"]],
    ["MIC", "Mikrofon Wireless", ["Aula Kampus"] * 2 + ["Ruang Seminar"] * 2 + ["Gudang UMPER"] * 2],
    ["SCR", "Layar Proyektor", ["Ruangan B", "Ruang Seminar", "Gudang UMPER"]],
    ["MJL", "Meja Lipat", ["Gudang UMPER"] * 10],
    ["KRS", "Kursi Lipat", ["Gudang UMPER"] * 30],
]


def data_barang() -> list[list]:
    return [[kode, nama, len(unit)] for kode, nama, unit in BARANG]


def data_ruangan() -> list[list]:
    return [list(r) for r in RUANGAN]


def data_dbr() -> list[list]:
    """Satu baris per unit fisik, dengan kode seperti stiker: UPITSM-PRY-001."""
    baris = []
    for kode, nama, unit in BARANG:
        for i, ruangan in enumerate(unit, start=1):
            baris.append([f"{PREFIX_STIKER}-{kode}-{i:03d}", nama, ruangan])
    return baris


def data_peminjaman(sekarang: datetime) -> list[list]:
    """Contoh peminjaman relatif terhadap hari ini, untuk menguji kasus bentrok.

    - Proyektor 3 unit, H+7 08:00-12:00, Disetujui      -> stok tersisa 2 di jam itu
    - Aula, H+8 13:00-16:00, Menunggu Verifikasi         -> Aula tidak tersedia di jam itu
    - Speaker 2 unit, H+7 09:00-11:00, Ditolak           -> diabaikan (tidak mengurangi stok)
    """
    h7 = (sekarang + timedelta(days=7)).replace(second=0, microsecond=0)
    h8 = (sekarang + timedelta(days=8)).replace(second=0, microsecond=0)

    def jam(hari: datetime, j: int) -> str:
        return hari.replace(hour=j, minute=0).strftime(FORMAT_WAKTU)

    diajukan = sekarang.strftime(FORMAT_WAKTU)
    tgl = sekarang.strftime("%Y%m%d")
    # Kolom: no, jenis, item, jumlah, ormawa, kegiatan, mulai, selesai,
    #        file_id_spj, file_id_sik, status, id_telegram, waktu_pengajuan
    return [
        [f"SU-{tgl}-0001", JENIS_BARANG, "PRY", 3, "HIMA Bisnis Digital", "Seminar Kewirausahaan",
         jam(h7, 8), jam(h7, 12), "CONTOH", "CONTOH", STATUS_DISETUJUI, "0", diajukan],
        [f"SU-{tgl}-0002", JENIS_RUANGAN, "AULA", 1, "BEM KEMA UPI Tasikmalaya", "Rapat Besar Ormawa",
         jam(h8, 13), jam(h8, 16), "CONTOH", "CONTOH", STATUS_MENUNGGU, "0", diajukan],
        [f"SU-{tgl}-0003", JENIS_BARANG, "SPK", 2, "UKM Musik", "Latihan Rutin",
         jam(h7, 9), jam(h7, 11), "CONTOH", "CONTOH", STATUS_DITOLAK, "0", diajukan],
    ]


def main() -> int:
    parser = argparse.ArgumentParser(description="Isi Google Sheets dengan data contoh SiUmper.")
    parser.add_argument("--yes", action="store_true", help="Lewati konfirmasi.")
    args = parser.parse_args()

    try:
        sheets = SheetsService(muat_config_sheets())
    except ConfigError as e:
        print(f"[GAGAL] Konfigurasi: {e}")
        return 1

    if not args.yes:
        jawab = input(
            "Isi sheet Barang, Ruangan, DBR, dan Peminjaman akan DITIMPA. Lanjutkan? (y/n): "
        )
        if jawab.strip().lower() not in {"y", "ya", "yes"}:
            print("Dibatalkan.")
            return 0

    sekarang = datetime.now()
    isi = {
        SHEET_BARANG: data_barang(),
        SHEET_RUANGAN: data_ruangan(),
        SHEET_DBR: data_dbr(),
        SHEET_PEMINJAMAN: data_peminjaman(sekarang),
    }

    try:
        for nama, baris in isi.items():
            sheets.tulis_ulang(nama, baris)
            print(f"[OK] Sheet '{nama}': {len(baris)} baris data")
    except SheetsError as e:
        print(f"[GAGAL] {e}")
        return 1

    h7 = (sekarang + timedelta(days=7)).strftime("%d-%m-%Y")
    h8 = (sekarang + timedelta(days=8)).strftime("%d-%m-%Y")
    print("\nSelesai. Skenario uji yang tersedia:")
    print(f"  - Proyektor tgl {h7} jam 08:00-12:00 hanya tersisa 2 unit (3 dipinjam).")
    print(f"  - Aula Kampus tgl {h8} jam 13:00-16:00 tidak tersedia (bentrok).")
    print(f"  - Speaker tgl {h7} tetap 4 unit (peminjaman berstatus Ditolak diabaikan).")
    print("  - Contoh kode stiker untuk /lokasi: UPITSM-TV-001 (Televisi, Ruangan A).")
    return 0


if __name__ == "__main__":
    sys.exit(main())
