"""Mengecek koneksi ke Google Sheets dan menampilkan jumlah baris tiap sheet.

Cara menjalankan (dari folder root proyek):
    python -m scripts.cek_koneksi
"""

import sys

from bot.config import ConfigError, muat_config_sheets
from bot.constants import HEADERS
from bot.services.sheets import SheetsError, SheetsService


def main() -> int:
    try:
        sheets = SheetsService(muat_config_sheets())
    except ConfigError as e:
        print(f"[GAGAL] Konfigurasi: {e}")
        return 1

    print(f"Service account : {sheets.email_service_account}")
    gagal = False
    for nama in HEADERS:
        try:
            jumlah = len(sheets.ambil_semua(nama))
            print(f"[OK]    {nama:<11} {jumlah} baris")
        except SheetsError as e:
            print(f"[GAGAL] {nama:<11} {e}")
            gagal = True

    if gagal:
        print("\nAda sheet yang bermasalah. Jika belum pernah, jalankan: python -m scripts.seed_data")
        return 1
    print("\nKoneksi Google Sheets berhasil.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
