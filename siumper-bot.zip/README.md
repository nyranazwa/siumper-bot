# SiUmper Bot

Chatbot Telegram untuk Reservasi, Peminjaman, dan Pelacakan Barang UMPER
UPI Kampus Tasikmalaya. Dibuat oleh Kelompok 8 sebagai prototipe awal.

Bot ini adalah antarmuka tambahan untuk dashboard SiUmper dan DBR yang
hanya bisa diakses dari jaringan kampus. Bot **tidak** memverifikasi SPJ/SIK
dan **tidak** menyetujui peminjaman. Keputusan tetap ada di Staf UMPER.

## Fitur

| Perintah | Fungsi |
|---|---|
| `/cek` | Cek ketersediaan barang/ruangan pada tanggal dan jam tertentu |
| `/pinjam` | Ajukan peminjaman (setelah `/cek`), unggah SPJ & SIK |
| `/lokasi` | Cek ruangan asal barang dari foto stiker atau kode inventaris |
| `/batal` | Batalkan proses yang sedang berjalan |
| `/bantuan` | Daftar perintah |
| `/idsaya` | Menampilkan chat ID (untuk mengisi `STAFF_CHAT_ID`) |

## Teknologi

Python 3.11+, python-telegram-bot, Gemini API (google-genai), Google Sheets (gspread).

## Persiapan

### 1. Membuat bot di BotFather
1. Buka Telegram, cari **@BotFather**.
2. Kirim `/newbot`, lalu isi nama bot (misal `SiUmper Bot`) dan username yang diakhiri `bot` (misal `siumper_upitsm_bot`).
3. Salin token yang diberikan ke `TELEGRAM_BOT_TOKEN` di `.env`.
4. (Opsional) Kirim `/setcommands` ke BotFather, pilih bot, lalu tempel:
   ```
   cek - Cek ketersediaan barang/ruangan
   pinjam - Ajukan peminjaman
   lokasi - Cek lokasi asal barang
   batal - Batalkan proses
   bantuan - Daftar perintah
   ```

### 2. Membuat API key Gemini
Buka https://aistudio.google.com/apikey, buat API key, lalu isi ke `GEMINI_API_KEY`.

### 3. Menyiapkan Google Sheets dan service account
1. Buka https://console.cloud.google.com, buat project baru.
2. Aktifkan **Google Sheets API** dan **Google Drive API**.
3. Buka *IAM & Admin > Service Accounts*, buat service account.
4. Di tab *Keys*, pilih *Add key > Create new key > JSON*. Simpan file sebagai `credentials/service_account.json`.
5. Buat spreadsheet kosong di Google Sheets. Share ke email `client_email` yang ada di file JSON dengan akses **Editor**.
6. Salin ID spreadsheet (bagian URL di antara `/d/` dan `/edit`) ke `SPREADSHEET_ID`.

### 4. Mengisi `.env`
Salin `.env.example` menjadi `.env`, lalu isi semua nilai. Untuk `STAFF_CHAT_ID`,
jalankan bot dulu, kirim `/idsaya` dari akun/grup Staf UMPER, salin angkanya,
lalu jalankan ulang bot.

## Menjalankan

```bash
python -m venv .venv
.venv\Scripts\activate          # Windows (Linux/Mac: source .venv/bin/activate)
pip install -r requirements.txt

python -m scripts.seed_data      # isi data contoh ke Google Sheets
python -m scripts.cek_koneksi    # cek koneksi Sheets
python -m bot.main               # jalankan bot
```

## Pengujian

```bash
pytest -v
```
Unit test mencakup parsing tanggal/jam (`tests/test_waktu.py`) dan logika
ketersediaan (`tests/test_ketersediaan.py`). Fitur yang memakai Telegram,
Gemini, dan Sheets diuji manual lewat chat dengan bot.

## Struktur Data (Google Sheets)

| Sheet | Kolom |
|---|---|
| Barang | kode_barang, nama_barang, stok_total |
| Ruangan | kode_ruangan, nama_ruangan, kapasitas |
| DBR | kode_barang, nama_barang, ruangan_asal |
| Peminjaman | no_peminjaman, jenis, item, jumlah, nama_ormawa, nama_kegiatan, tanggal_mulai, tanggal_selesai, file_id_spj, file_id_sik, status, id_telegram_pengaju, waktu_pengajuan |

Ketersediaan dihitung dari baris Peminjaman berstatus **Menunggu Verifikasi**
atau **Disetujui** yang waktunya bentrok. Status diubah manual oleh Staf UMPER
langsung di sheet.

## Keterbatasan Prototipe
- Database masih Google Sheets (belum terhubung ke database SiUmper/DBR asli).
- Belum ada perintah untuk staf; verifikasi dilakukan langsung di sheet.
- Pengguna belum mendapat notifikasi otomatis saat status berubah.
- Nomor peminjaman dibuat dari urutan harian dan belum aman untuk pengajuan yang benar-benar bersamaan.
