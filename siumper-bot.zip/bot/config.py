"""Konfigurasi aplikasi. Semua nilai rahasia dibaca dari file .env."""

import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

# Folder root proyek (satu tingkat di atas folder bot/)
BASE_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BASE_DIR / ".env")


class ConfigError(RuntimeError):
    """Dilempar jika ada variabel .env yang belum diisi atau salah."""


def _wajib(nama: str) -> str:
    nilai = os.getenv(nama, "").strip()
    if not nilai:
        raise ConfigError(
            f"Variabel '{nama}' belum diisi di file .env. "
            "Salin .env.example menjadi .env lalu lengkapi isinya."
        )
    return nilai


@dataclass(frozen=True)
class SheetsConfig:
    service_account_file: Path
    spreadsheet_id: str


@dataclass(frozen=True)
class BotConfig:
    telegram_token: str
    gemini_api_key: str
    gemini_model: str
    staff_chat_id: int
    timezone: str
    max_file_mb: int


def muat_config_sheets() -> SheetsConfig:
    """Konfigurasi minimal untuk mengakses Google Sheets (dipakai juga oleh seed_data)."""
    path = Path(_wajib("GOOGLE_SERVICE_ACCOUNT_FILE"))
    if not path.is_absolute():
        path = BASE_DIR / path
    if not path.exists():
        raise ConfigError(
            f"File service account tidak ditemukan di '{path}'. "
            "Unduh file JSON dari Google Cloud Console lalu simpan di folder credentials/."
        )
    return SheetsConfig(service_account_file=path, spreadsheet_id=_wajib("SPREADSHEET_ID"))


def muat_config_bot() -> BotConfig:
    """Konfigurasi lengkap untuk menjalankan bot Telegram."""
    staff_raw = _wajib("STAFF_CHAT_ID")
    try:
        staff_chat_id = int(staff_raw)
    except ValueError as e:
        raise ConfigError(f"STAFF_CHAT_ID harus berupa angka, bukan '{staff_raw}'.") from e

    max_mb_raw = os.getenv("MAX_FILE_MB", "5").strip() or "5"
    try:
        max_file_mb = int(max_mb_raw)
    except ValueError as e:
        raise ConfigError(f"MAX_FILE_MB harus berupa angka, bukan '{max_mb_raw}'.") from e

    return BotConfig(
        telegram_token=_wajib("TELEGRAM_BOT_TOKEN"),
        gemini_api_key=_wajib("GEMINI_API_KEY"),
        gemini_model=os.getenv("GEMINI_MODEL", "gemini-2.5-flash").strip() or "gemini-2.5-flash",
        staff_chat_id=staff_chat_id,
        timezone=os.getenv("TIMEZONE", "Asia/Jakarta").strip() or "Asia/Jakarta",
        max_file_mb=max_file_mb,
    )
