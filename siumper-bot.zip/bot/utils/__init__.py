"""Fungsi bantu yang tidak bergantung pada Telegram maupun Google Sheets."""
