"""Fungsi bantu pengolahan teks."""

import re


def normalisasi_kode(kode: str) -> str:
    """Seragamkan kode inventaris agar pencarian tidak sensitif spasi/huruf besar.

    Contoh: " upitsm pry 001 " -> "UPITSM-PRY-001"
            "UPITSM/PRY/001"   -> "UPITSM-PRY-001"
    """
    kode = kode.strip().upper()
    # Spasi, garis miring, titik, dan garis bawah dianggap sama dengan tanda hubung
    kode = re.sub(r"[\s/._]+", "-", kode)
    kode = re.sub(r"-{2,}", "-", kode)
    return kode.strip("-")
