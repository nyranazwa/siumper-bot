"""Parsing dan format tanggal/jam yang diketik pengguna."""

import re
from datetime import datetime
from zoneinfo import ZoneInfo

CONTOH_RENTANG = "20-10-2026 08:00-12:00"
CONTOH_WAKTU = "20-10-2026 08:00"

# Tanggal: DD-MM-YYYY atau DD/MM/YYYY. Jam: JJ:MM atau JJ.MM
_TANGGAL = r"(\d{1,2})[-/](\d{1,2})[-/](\d{4})"
_JAM = r"(\d{1,2})[:.](\d{2})"


class FormatWaktuSalah(ValueError):
    """Format tanggal/jam yang diketik pengguna tidak sesuai."""


def _buat(tgl: str, bln: str, thn: str, jam: str, mnt: str) -> datetime:
    try:
        return datetime(int(thn), int(bln), int(tgl), int(jam), int(mnt))
    except ValueError:
        raise FormatWaktuSalah("Tanggal atau jam tidak valid.") from None


def parse_waktu(teks: str) -> datetime:
    """'20-10-2026 08:00' -> datetime(2026, 10, 20, 8, 0)"""
    m = re.fullmatch(rf"\s*{_TANGGAL}\s+{_JAM}\s*", teks)
    if not m:
        raise FormatWaktuSalah("Format tanggal/jam belum sesuai.")
    return _buat(*m.groups())


def parse_rentang(teks: str) -> tuple[datetime, datetime]:
    """'20-10-2026 08:00-12:00' -> (mulai, selesai) pada tanggal yang sama."""
    m = re.fullmatch(
        rf"\s*{_TANGGAL}\s+{_JAM}\s*(?:-|s\.?d\.?|sampai)\s*{_JAM}\s*",
        teks,
        flags=re.IGNORECASE,
    )
    if not m:
        raise FormatWaktuSalah("Format tanggal/jam belum sesuai.")
    tgl, bln, thn, j1, m1, j2, m2 = m.groups()
    mulai = _buat(tgl, bln, thn, j1, m1)
    selesai = _buat(tgl, bln, thn, j2, m2)
    if selesai <= mulai:
        raise FormatWaktuSalah("Jam selesai harus setelah jam mulai.")
    return mulai, selesai


def format_waktu(dt: datetime) -> str:
    """Format tampilan untuk pengguna: 20-10-2026 08:00"""
    return dt.strftime("%d-%m-%Y %H:%M")


def sekarang(timezone: str = "Asia/Jakarta") -> datetime:
    """Waktu sekarang di zona kampus (tanpa info zona, agar bisa dibandingkan)."""
    return datetime.now(ZoneInfo(timezone)).replace(tzinfo=None)
