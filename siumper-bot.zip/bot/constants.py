"""Konstanta bersama: nama sheet, header kolom, status, dan format waktu."""

# Nama worksheet di Google Sheets
SHEET_BARANG = "Barang"
SHEET_RUANGAN = "Ruangan"
SHEET_DBR = "DBR"
SHEET_PEMINJAMAN = "Peminjaman"

# Urutan kolom tiap sheet (baris pertama = header)
HEADERS: dict[str, list[str]] = {
    SHEET_BARANG: ["kode_barang", "nama_barang", "stok_total"],
    SHEET_RUANGAN: ["kode_ruangan", "nama_ruangan", "kapasitas"],
    SHEET_DBR: ["kode_barang", "nama_barang", "ruangan_asal"],
    SHEET_PEMINJAMAN: [
        "no_peminjaman",
        "jenis",
        "item",
        "jumlah",
        "nama_ormawa",
        "nama_kegiatan",
        "tanggal_mulai",
        "tanggal_selesai",
        "file_id_spj",
        "file_id_sik",
        "status",
        "id_telegram_pengaju",
        "waktu_pengajuan",
    ],
}

# Jenis peminjaman
JENIS_BARANG = "barang"
JENIS_RUANGAN = "ruangan"

# Status peminjaman. Hanya status "aktif" yang mengurangi ketersediaan.
STATUS_MENUNGGU = "Menunggu Verifikasi"
STATUS_DISETUJUI = "Disetujui"
STATUS_DITOLAK = "Ditolak"
STATUS_SELESAI = "Selesai"
STATUS_AKTIF = {STATUS_MENUNGGU, STATUS_DISETUJUI}

# Format waktu yang disimpan di sheet (string, bukan format tanggal Sheets)
FORMAT_WAKTU = "%Y-%m-%d %H:%M"
