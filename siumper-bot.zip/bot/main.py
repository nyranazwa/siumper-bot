"""Titik masuk bot SiUmper.

Cara menjalankan (dari folder root proyek):
    python -m bot.main
"""

import logging
import sys

from telegram.ext import Application, CommandHandler, MessageHandler, filters

from bot.config import ConfigError, muat_config_bot, muat_config_sheets
from bot.handlers.cek import buat_handler_cek
from bot.handlers.lokasi import buat_handler_lokasi
from bot.handlers.pinjam import buat_handler_pinjam
from bot.handlers.umum import (
    bantuan,
    batal,
    idsaya,
    perintah_tidak_dikenal,
    start,
    tangani_error,
    teks_bebas,
)
from bot.services.gemini import GeminiService
from bot.services.sheets import SheetsService


def main() -> None:
    logging.basicConfig(
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        level=logging.INFO,
    )
    logging.getLogger("httpx").setLevel(logging.WARNING)

    try:
        config = muat_config_bot()
        sheets_config = muat_config_sheets()
    except ConfigError as e:
        print(f"[GAGAL] Konfigurasi: {e}")
        sys.exit(1)

    app = Application.builder().token(config.telegram_token).build()

    # Service dibagikan ke semua handler lewat context.bot_data
    app.bot_data["config"] = config
    app.bot_data["sheets"] = SheetsService(sheets_config)
    app.bot_data["gemini"] = GeminiService(config.gemini_api_key, config.gemini_model)

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler(["bantuan", "help"], bantuan))
    app.add_handler(CommandHandler("idsaya", idsaya))
    app.add_handler(buat_handler_cek())
    app.add_handler(buat_handler_pinjam())
    app.add_handler(buat_handler_lokasi())
    app.add_handler(CommandHandler("batal", batal))
    # Harus paling akhir: menangkap perintah/teks yang tidak dikenali
    app.add_handler(MessageHandler(filters.COMMAND, perintah_tidak_dikenal))
    app.add_handler(MessageHandler(filters.TEXT, teks_bebas))
    app.add_error_handler(tangani_error)

    logging.info("Bot SiUmper berjalan. Tekan Ctrl+C untuk berhenti.")
    app.run_polling()


if __name__ == "__main__":
    main()
