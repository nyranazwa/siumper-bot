"""Perintah umum: /start, /bantuan, /idsaya, /batal, dan pesan yang tidak dikenali."""

import logging

from telegram import Update
from telegram.ext import ContextTypes, ConversationHandler

logger = logging.getLogger(__name__)

TEKS_BANTUAN = (
    "Halo! Aku SiUmper, chatbot layanan UMPER UPI Kampus Tasikmalaya.\n\n"
    "Perintah yang tersedia:\n"
    "/cek - Cek ketersediaan barang atau ruangan\n"
    "/pinjam - Ajukan peminjaman (setelah /cek)\n"
    "/lokasi - Cek ruangan asal barang dari kode stiker\n"
    "/batal - Batalkan proses yang sedang berjalan\n"
    "/bantuan - Tampilkan daftar perintah\n\n"
    "Catatan: bot hanya meneruskan pengajuan. Persetujuan peminjaman "
    "tetap dilakukan oleh Staf UMPER."
)

PESAN_GANGGUAN = (
    "Maaf, sistem sedang mengalami gangguan saat mengambil data. "
    "Silakan coba beberapa saat lagi."
)


async def start(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(TEKS_BANTUAN)


async def bantuan(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(TEKS_BANTUAN)


async def idsaya(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Membantu mengisi STAFF_CHAT_ID di .env."""
    await update.message.reply_text(f"Chat ID ini: {update.effective_chat.id}")


async def batal(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.clear()
    await update.message.reply_text("Proses dibatalkan. Tidak ada data yang disimpan.")
    return ConversationHandler.END


async def perintah_tidak_dikenal(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text("Perintah tidak dikenali.\n\n" + TEKS_BANTUAN)


async def teks_bebas(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    await update.message.reply_text(
        "Silakan gunakan perintah ya. Ketik /bantuan untuk melihat daftar perintah."
    )


async def tangani_error(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    logger.error("Terjadi error", exc_info=context.error)
    if isinstance(update, Update) and update.effective_message:
        await update.effective_message.reply_text(PESAN_GANGGUAN)
