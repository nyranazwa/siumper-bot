"""UC-03 /lokasi: mengecek ruangan asal (DBR) dari kode stiker barang.

Fitur ini hanya menampilkan lokasi resmi barang, TIDAK menampilkan status
peminjaman maupun nama peminjam.
"""

import asyncio
import logging

from telegram import Update
from telegram.ext import (
    CommandHandler,
    ContextTypes,
    ConversationHandler,
    MessageHandler,
    filters,
)

from bot.handlers.umum import PESAN_GANGGUAN, batal
from bot.services.sheets import SheetsError

logger = logging.getLogger(__name__)

TUNGGU_KODE = 0


async def mulai_lokasi(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text(
        "Kirim foto stiker kode inventaris pada barang, atau ketik kodenya.\n"
        "Contoh kode: UPITSM-TV-001"
    )
    return TUNGGU_KODE


async def terima_foto(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    await update.message.reply_text("Sedang membaca kode pada foto...")
    foto = update.message.photo[-1]  # resolusi terbesar
    berkas = await foto.get_file()
    gambar = bytes(await berkas.download_as_bytearray())

    kode = await context.bot_data["gemini"].baca_kode_stiker(gambar)
    if not kode:
        await update.message.reply_text(
            "Maaf, kode belum terbaca. Coba foto ulang lebih dekat dengan cahaya yang cukup, "
            "atau ketik kodenya secara manual."
        )
        return TUNGGU_KODE

    await update.message.reply_text(f"Kode terbaca: {kode}")
    return await _cari_lokasi(update, context, kode)


async def terima_teks(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    return await _cari_lokasi(update, context, update.message.text)


async def _cari_lokasi(update: Update, context: ContextTypes.DEFAULT_TYPE, kode: str) -> int:
    try:
        row = await asyncio.to_thread(context.bot_data["sheets"].cari_dbr, kode)
    except SheetsError:
        logger.exception("Gagal membaca DBR")
        await update.message.reply_text(PESAN_GANGGUAN)
        return ConversationHandler.END

    if row is None:
        await update.message.reply_text(
            f"Kode barang \"{kode.strip()}\" tidak terdaftar di DBR.\n"
            "Silakan periksa kembali kodenya atau hubungi Staf UMPER."
        )
    else:
        await update.message.reply_text(
            "Lokasi asal barang\n\n"
            f"Nama barang : {row['nama_barang']}\n"
            f"Kode        : {row['kode_barang']}\n"
            f"Ruangan asal: {row['ruangan_asal']}"
        )
    return ConversationHandler.END


def buat_handler_lokasi() -> ConversationHandler:
    return ConversationHandler(
        entry_points=[CommandHandler("lokasi", mulai_lokasi)],
        states={
            TUNGGU_KODE: [
                MessageHandler(filters.PHOTO, terima_foto),
                MessageHandler(filters.TEXT & ~filters.COMMAND, terima_teks),
            ],
        },
        fallbacks=[CommandHandler("batal", batal)],
        allow_reentry=True,
    )
