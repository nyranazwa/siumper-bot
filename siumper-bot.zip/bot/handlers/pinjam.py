"""UC-02 /pinjam: pengajuan peminjaman (reservasi) barang atau ruangan.

Pengguna boleh menjawab satu per satu atau langsung dengan kalimat bebas,
misalnya: "pinjam proyektor 2 buah tgl 20 Oktober jam 8 sampai 12 untuk HIMA Bisdig".
Gemini mengekstrak datanya, lalu bot tetap meminta konfirmasi sebelum menyimpan.
Bot TIDAK memverifikasi SPJ/SIK dan TIDAK menyetujui peminjaman.
"""

import asyncio
import logging
from datetime import datetime

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    ConversationHandler,
    MessageHandler,
    filters,
)

from bot.constants import FORMAT_WAKTU, JENIS_BARANG, STATUS_MENUNGGU
from bot.handlers.umum import PESAN_GANGGUAN, batal
from bot.services.ketersediaan import cek_ketersediaan, saran_waktu
from bot.services.sheets import SheetsError
from bot.utils.waktu import CONTOH_WAKTU, FormatWaktuSalah, format_waktu, parse_waktu, sekarang

logger = logging.getLogger(__name__)

KONFIRMASI_PILIHAN, ISI_DATA, KIRIM_SPJ, KIRIM_SIK, KONFIRMASI_AKHIR = range(5)

EKSTENSI_BERKAS = {"pdf", "jpg", "jpeg", "png"}

# Urutan pertanyaan formulir. "jumlah" hanya untuk barang.
PERTANYAAN = [
    ("nama_ormawa", "Apa nama ORMAWA yang meminjam?\nContoh: HIMA Bisnis Digital"),
    ("nama_kegiatan", "Apa nama kegiatannya?\nContoh: Seminar Kewirausahaan"),
    ("waktu_pinjam", f"Tanggal dan jam mulai pinjam?\nFormat: DD-MM-YYYY JJ:MM\nContoh: {CONTOH_WAKTU}"),
    ("waktu_kembali", "Tanggal dan jam pengembalian?\nFormat: DD-MM-YYYY JJ:MM\nContoh: 20-10-2026 12:00"),
    ("jumlah", "Berapa jumlah barang yang dipinjam?\nContoh: 2"),
]


def _pertanyaan_berikutnya(pinjam: dict) -> tuple[str, str] | None:
    for kunci, teks in PERTANYAAN:
        if kunci == "jumlah" and pinjam["jenis"] != JENIS_BARANG:
            continue
        if kunci not in pinjam["data"]:
            return kunci, teks
    return None


def _validasi(kunci: str, nilai) -> object:
    """Ubah nilai mentah menjadi nilai yang valid. Lempar ValueError jika tidak sesuai."""
    if kunci in ("nama_ormawa", "nama_kegiatan"):
        teks = str(nilai).strip()
        if not teks or len(teks) > 100:
            raise ValueError("Isian tidak boleh kosong dan maksimal 100 karakter.")
        return teks
    if kunci in ("waktu_pinjam", "waktu_kembali"):
        return parse_waktu(str(nilai))
    if kunci == "jumlah":
        jumlah = int(str(nilai).strip())
        if jumlah <= 0:
            raise ValueError("Jumlah harus lebih dari 0.")
        return jumlah
    raise ValueError("Kunci tidak dikenal.")


# ----------------------------------------------------------------------
# Langkah 1: konfirmasi pilihan dari /cek
# ----------------------------------------------------------------------
async def mulai_pinjam(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    cek = context.user_data.get("cek")
    if not cek or not cek.get("tersedia"):
        await update.message.reply_text(
            "Sebelum meminjam, cek ketersediaan dulu dengan /cek "
            "dan pastikan barang/ruangan berstatus tersedia."
        )
        return ConversationHandler.END

    context.user_data["pinjam"] = {
        "jenis": cek["jenis"],
        "kode": cek["kode"],
        "nama": cek["nama"],
        "stok_total": cek["stok_total"],
        "data": {},
    }
    tombol = InlineKeyboardMarkup([[
        InlineKeyboardButton("Ya, lanjutkan", callback_data="pilihan:ya"),
        InlineKeyboardButton("Batal", callback_data="pilihan:batal"),
    ]])
    await update.message.reply_text(
        f"Kamu akan mengajukan peminjaman {cek['jenis']}: {cek['nama']}.\nLanjutkan?",
        reply_markup=tombol,
    )
    return KONFIRMASI_PILIHAN


async def konfirmasi_pilihan(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    if query.data != "pilihan:ya":
        context.user_data.pop("pinjam", None)
        await query.edit_message_text("Pengajuan dibatalkan. Tidak ada data yang disimpan.")
        return ConversationHandler.END

    await query.edit_message_text(
        "Baik, isi data peminjaman ya.\n"
        "Kamu bisa menjawab satu per satu, atau langsung dalam satu kalimat, misalnya:\n"
        "\"pinjam 2 buah tgl 20-10-2026 jam 8 sampai 12 untuk HIMA Bisdig, kegiatan Seminar\"\n\n"
        "Ketik /batal kapan saja untuk berhenti."
    )
    _, pertanyaan = _pertanyaan_berikutnya(context.user_data["pinjam"])
    await query.message.reply_text(pertanyaan)
    return ISI_DATA


# ----------------------------------------------------------------------
# Langkah 2: isi data formulir (dibantu Gemini)
# ----------------------------------------------------------------------
async def isi_data(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    pinjam = context.user_data["pinjam"]
    data = pinjam["data"]
    config = context.bot_data["config"]
    kunci_sekarang, pertanyaan = _pertanyaan_berikutnya(pinjam)
    teks = update.message.text.strip()

    hasil = await context.bot_data["gemini"].ekstrak_data_peminjaman(
        teks, pertanyaan, sekarang(config.timezone).year
    )
    if not hasil:
        # Cadangan jika Gemini gagal: jawaban dianggap untuk pertanyaan saat ini
        hasil = {kunci_sekarang: teks}

    for kunci, nilai in hasil.items():
        if kunci not in dict(PERTANYAAN):
            continue
        if kunci == "jumlah" and pinjam["jenis"] != JENIS_BARANG:
            continue
        try:
            data[kunci] = _validasi(kunci, nilai)
        except (ValueError, FormatWaktuSalah):
            continue

    # Validasi antar-field waktu
    if "waktu_pinjam" in data and data["waktu_pinjam"] < sekarang(config.timezone):
        data.pop("waktu_pinjam")
        await update.message.reply_text("Waktu pinjam sudah lewat, silakan masukkan waktu yang akan datang.")
    if "waktu_pinjam" in data and "waktu_kembali" in data and data["waktu_kembali"] <= data["waktu_pinjam"]:
        data.pop("waktu_kembali")
        await update.message.reply_text("Waktu pengembalian harus setelah waktu pinjam.")

    berikutnya = _pertanyaan_berikutnya(pinjam)
    if berikutnya:
        kunci, pertanyaan = berikutnya
        if kunci == kunci_sekarang:
            await update.message.reply_text("Jawaban belum sesuai format.\n\n" + pertanyaan)
        else:
            await update.message.reply_text(pertanyaan)
        return ISI_DATA

    return await _cek_ulang(update, context)


async def _cek_ulang(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    """Cek ulang ketersediaan dengan data final sebelum meminta berkas."""
    pinjam = context.user_data["pinjam"]
    data = pinjam["data"]
    try:
        peminjaman = await asyncio.to_thread(context.bot_data["sheets"].daftar_peminjaman)
    except SheetsError:
        logger.exception("Gagal membaca data peminjaman")
        await update.message.reply_text(PESAN_GANGGUAN)
        return ConversationHandler.END

    hasil = cek_ketersediaan(
        pinjam["jenis"], pinjam["kode"], data["waktu_pinjam"], data["waktu_kembali"],
        peminjaman, stok_total=pinjam["stok_total"], jumlah=data.get("jumlah", 1),
    )
    if not hasil.tersedia:
        teks = f"Maaf, {pinjam['nama']} tidak tersedia pada waktu tersebut"
        if pinjam["jenis"] == JENIS_BARANG:
            teks += f" (sisa stok: {hasil.sisa})"
        teks += ". Pengajuan dibatalkan.\n"
        saran = saran_waktu(hasil.bentrok)
        if saran:
            teks += f"Saran: coba setelah {format_waktu(saran)}.\n"
        teks += "Silakan /cek lagi untuk waktu lain."
        context.user_data.pop("pinjam", None)
        await update.message.reply_text(teks)
        return ConversationHandler.END

    maks = context.bot_data["config"].max_file_mb
    await update.message.reply_text(
        "Data lengkap dan item masih tersedia.\n\n"
        f"Sekarang kirim berkas SPJ sebagai file (PDF/JPG/PNG, maksimal {maks} MB)."
    )
    return KIRIM_SPJ


# ----------------------------------------------------------------------
# Langkah 3: unggah berkas SPJ dan SIK
# ----------------------------------------------------------------------
async def _periksa_berkas(update: Update, context: ContextTypes.DEFAULT_TYPE, nama: str) -> str | None:
    """Kembalikan file_id jika berkas valid. Jika tidak, kirim pesan dan kembalikan None."""
    doc = update.message.document
    maks = context.bot_data["config"].max_file_mb
    if doc is None:
        await update.message.reply_text(
            f"Kirim berkas {nama} sebagai file/dokumen (ikon klip > File), "
            f"format PDF/JPG/PNG maksimal {maks} MB."
        )
        return None
    ekstensi = (doc.file_name or "").rsplit(".", 1)[-1].lower()
    if ekstensi not in EKSTENSI_BERKAS:
        await update.message.reply_text(f"Format berkas {nama} harus PDF, JPG, atau PNG. Silakan kirim ulang.")
        return None
    if doc.file_size and doc.file_size > maks * 1024 * 1024:
        await update.message.reply_text(f"Ukuran berkas {nama} melebihi {maks} MB. Silakan kirim ulang.")
        return None
    return doc.file_id


async def terima_spj(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    file_id = await _periksa_berkas(update, context, "SPJ")
    if not file_id:
        return KIRIM_SPJ
    context.user_data["pinjam"]["file_id_spj"] = file_id
    await update.message.reply_text("SPJ diterima. Sekarang kirim berkas SIK.")
    return KIRIM_SIK


async def terima_sik(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    file_id = await _periksa_berkas(update, context, "SIK")
    if not file_id:
        return KIRIM_SIK
    pinjam = context.user_data["pinjam"]
    pinjam["file_id_sik"] = file_id

    tombol = InlineKeyboardMarkup([[
        InlineKeyboardButton("Kirim Pengajuan", callback_data="akhir:ya"),
        InlineKeyboardButton("Batal", callback_data="akhir:batal"),
    ]])
    await update.message.reply_text(_ringkasan(pinjam) + "\n\nApakah data sudah benar?", reply_markup=tombol)
    return KONFIRMASI_AKHIR


def _ringkasan(pinjam: dict) -> str:
    data = pinjam["data"]
    baris = [
        "Ringkasan Pengajuan",
        f"Jenis      : {pinjam['jenis']}",
        f"Item       : {pinjam['nama']}",
    ]
    if pinjam["jenis"] == JENIS_BARANG:
        baris.append(f"Jumlah     : {data['jumlah']}")
    baris += [
        f"ORMAWA     : {data['nama_ormawa']}",
        f"Kegiatan   : {data['nama_kegiatan']}",
        f"Pinjam     : {format_waktu(data['waktu_pinjam'])}",
        f"Kembali    : {format_waktu(data['waktu_kembali'])}",
        "Berkas     : SPJ dan SIK terlampir",
    ]
    return "\n".join(baris)


# ----------------------------------------------------------------------
# Langkah 4: simpan dan kirim notifikasi ke Staf UMPER
# ----------------------------------------------------------------------
def _buat_nomor(peminjaman: list[dict], waktu: datetime) -> str:
    """Nomor urut harian: SU-YYYYMMDD-0001. (Prototipe: belum aman untuk pengajuan bersamaan.)"""
    prefix = f"SU-{waktu:%Y%m%d}-"
    urutan = sum(1 for row in peminjaman if row.get("no_peminjaman", "").startswith(prefix))
    return f"{prefix}{urutan + 1:04d}"


async def konfirmasi_akhir(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    pinjam = context.user_data.get("pinjam")
    if query.data != "akhir:ya" or not pinjam:
        context.user_data.pop("pinjam", None)
        await query.edit_message_text("Pengajuan dibatalkan. Tidak ada data yang disimpan.")
        return ConversationHandler.END

    config = context.bot_data["config"]
    sheets = context.bot_data["sheets"]
    data = pinjam["data"]
    waktu_sekarang = sekarang(config.timezone)

    try:
        peminjaman = await asyncio.to_thread(sheets.daftar_peminjaman)
        nomor = _buat_nomor(peminjaman, waktu_sekarang)
        await asyncio.to_thread(sheets.simpan_peminjaman, {
            "no_peminjaman": nomor,
            "jenis": pinjam["jenis"],
            "item": pinjam["kode"],
            "jumlah": data.get("jumlah", 1),
            "nama_ormawa": data["nama_ormawa"],
            "nama_kegiatan": data["nama_kegiatan"],
            "tanggal_mulai": data["waktu_pinjam"].strftime(FORMAT_WAKTU),
            "tanggal_selesai": data["waktu_kembali"].strftime(FORMAT_WAKTU),
            "file_id_spj": pinjam["file_id_spj"],
            "file_id_sik": pinjam["file_id_sik"],
            "status": STATUS_MENUNGGU,
            "id_telegram_pengaju": update.effective_user.id,
            "waktu_pengajuan": waktu_sekarang.strftime(FORMAT_WAKTU),
        })
    except SheetsError:
        logger.exception("Gagal menyimpan peminjaman")
        await query.edit_message_text(PESAN_GANGGUAN + "\nPengajuan belum tersimpan.")
        return ConversationHandler.END

    await query.edit_message_text(
        "Pengajuan berhasil dikirim!\n\n"
        f"Nomor peminjaman: {nomor}\n"
        f"Status: {STATUS_MENUNGGU}\n\n"
        "Staf UMPER akan memeriksa SPJ dan SIK kamu. "
        "Simpan nomor peminjaman ini untuk keperluan konfirmasi."
    )

    # Notifikasi ke Staf UMPER (gagal kirim notifikasi tidak membatalkan pengajuan)
    try:
        await context.bot.send_message(
            config.staff_chat_id,
            f"[Pengajuan Baru] {nomor}\n\n{_ringkasan(pinjam)}\n"
            f"Pengaju (ID Telegram): {update.effective_user.id}\n"
            f"Status: {STATUS_MENUNGGU}",
        )
        await context.bot.send_document(config.staff_chat_id, pinjam["file_id_spj"], caption=f"SPJ {nomor}")
        await context.bot.send_document(config.staff_chat_id, pinjam["file_id_sik"], caption=f"SIK {nomor}")
    except Exception:
        logger.exception("Gagal mengirim notifikasi ke Staf UMPER")

    context.user_data.pop("pinjam", None)
    context.user_data.pop("cek", None)
    return ConversationHandler.END


def buat_handler_pinjam() -> ConversationHandler:
    berkas = filters.ALL & ~filters.COMMAND
    return ConversationHandler(
        entry_points=[CommandHandler("pinjam", mulai_pinjam)],
        states={
            KONFIRMASI_PILIHAN: [CallbackQueryHandler(konfirmasi_pilihan, pattern=r"^pilihan:")],
            ISI_DATA: [MessageHandler(filters.TEXT & ~filters.COMMAND, isi_data)],
            KIRIM_SPJ: [MessageHandler(berkas, terima_spj)],
            KIRIM_SIK: [MessageHandler(berkas, terima_sik)],
            KONFIRMASI_AKHIR: [CallbackQueryHandler(konfirmasi_akhir, pattern=r"^akhir:")],
        },
        fallbacks=[CommandHandler("batal", batal)],
        allow_reentry=True,
    )
