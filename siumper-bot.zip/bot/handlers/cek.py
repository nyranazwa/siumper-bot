"""UC-01 /cek: mengecek ketersediaan barang atau ruangan."""

import asyncio
import logging

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, Update
from telegram.ext import (
    CallbackQueryHandler,
    CommandHandler,
    ContextTypes,
    ConversationHandler,
    MessageHandler,
    filters,
)

from bot.constants import JENIS_BARANG, JENIS_RUANGAN
from bot.handlers.umum import PESAN_GANGGUAN, batal
from bot.services.ketersediaan import cek_ketersediaan, saran_waktu
from bot.services.sheets import SheetsError
from bot.utils.waktu import CONTOH_RENTANG, FormatWaktuSalah, format_waktu, parse_rentang, sekarang

logger = logging.getLogger(__name__)

PILIH_JENIS, PILIH_ITEM, ISI_WAKTU, ISI_JUMLAH = range(4)


async def mulai_cek(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    context.user_data.pop("cek", None)
    tombol = InlineKeyboardMarkup([[
        InlineKeyboardButton("Barang", callback_data=f"jenis:{JENIS_BARANG}"),
        InlineKeyboardButton("Ruangan", callback_data=f"jenis:{JENIS_RUANGAN}"),
    ]])
    await update.message.reply_text("Mau cek ketersediaan apa?", reply_markup=tombol)
    return PILIH_JENIS


async def pilih_jenis(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    jenis = query.data.split(":", 1)[1]
    sheets = context.bot_data["sheets"]

    try:
        if jenis == JENIS_BARANG:
            daftar = await asyncio.to_thread(sheets.daftar_barang)
        else:
            daftar = await asyncio.to_thread(sheets.daftar_ruangan)
    except SheetsError:
        logger.exception("Gagal mengambil daftar %s", jenis)
        await query.edit_message_text(PESAN_GANGGUAN)
        return ConversationHandler.END

    tombol, data_item = [], {}
    for row in daftar:
        if jenis == JENIS_BARANG:
            kode, nama = row["kode_barang"], row["nama_barang"]
            label = f"{nama} (stok {row['stok_total']})"
            stok = int(row["stok_total"] or 0)
        else:
            kode, nama = row["kode_ruangan"], row["nama_ruangan"]
            label = f"{nama} (kapasitas {row['kapasitas']})"
            stok = 1
        data_item[kode] = {"nama": nama, "stok_total": stok}
        tombol.append([InlineKeyboardButton(label, callback_data=f"item:{kode}")])

    context.user_data["cek"] = {"jenis": jenis, "daftar": data_item}
    await query.edit_message_text(f"Pilih {jenis}:", reply_markup=InlineKeyboardMarkup(tombol))
    return PILIH_ITEM


async def pilih_item(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    query = update.callback_query
    await query.answer()
    cek = context.user_data.get("cek")
    kode = query.data.split(":", 1)[1]
    if not cek or kode not in cek["daftar"]:
        await query.edit_message_text("Sesi sudah berakhir. Silakan ketik /cek lagi.")
        return ConversationHandler.END

    item = cek.pop("daftar")[kode]
    cek.update(kode=kode, nama=item["nama"], stok_total=item["stok_total"])
    await query.edit_message_text(
        f"Kamu memilih: {item['nama']}\n\n"
        "Ketik tanggal dan jam pemakaian.\n"
        "Format: DD-MM-YYYY JJ:MM-JJ:MM\n"
        f"Contoh: {CONTOH_RENTANG}"
    )
    return ISI_WAKTU


async def isi_waktu(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    cek = context.user_data["cek"]
    try:
        mulai, selesai = parse_rentang(update.message.text)
    except FormatWaktuSalah as e:
        await update.message.reply_text(
            f"{e}\nSilakan ketik ulang dengan format DD-MM-YYYY JJ:MM-JJ:MM\n"
            f"Contoh: {CONTOH_RENTANG}"
        )
        return ISI_WAKTU

    if mulai < sekarang(context.bot_data["config"].timezone):
        await update.message.reply_text("Waktu tersebut sudah lewat. Silakan masukkan waktu yang akan datang.")
        return ISI_WAKTU

    cek.update(mulai=mulai, selesai=selesai)
    if cek["jenis"] == JENIS_BARANG:
        await update.message.reply_text("Berapa jumlah yang dibutuhkan? (contoh: 2)")
        return ISI_JUMLAH

    cek["jumlah"] = 1
    return await _proses_cek(update, context)


async def isi_jumlah(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    teks = update.message.text.strip()
    if not teks.isdigit() or int(teks) <= 0:
        await update.message.reply_text("Jumlah harus berupa angka lebih dari 0. Contoh: 2")
        return ISI_JUMLAH
    context.user_data["cek"]["jumlah"] = int(teks)
    return await _proses_cek(update, context)


async def _proses_cek(update: Update, context: ContextTypes.DEFAULT_TYPE) -> int:
    cek = context.user_data["cek"]
    try:
        peminjaman = await asyncio.to_thread(context.bot_data["sheets"].daftar_peminjaman)
    except SheetsError:
        logger.exception("Gagal membaca data peminjaman")
        await update.message.reply_text(PESAN_GANGGUAN)
        return ConversationHandler.END

    hasil = cek_ketersediaan(
        cek["jenis"], cek["kode"], cek["mulai"], cek["selesai"],
        peminjaman, stok_total=cek["stok_total"], jumlah=cek["jumlah"],
    )
    cek["tersedia"] = hasil.tersedia
    waktu = f"{format_waktu(cek['mulai'])} s.d. {cek['selesai']:%H:%M}"

    if hasil.tersedia:
        teks = f"TERSEDIA\n\n{cek['nama']}\nWaktu: {waktu}\n"
        if cek["jenis"] == JENIS_BARANG:
            teks += f"Jumlah diminta: {cek['jumlah']} (sisa stok: {hasil.sisa})\n"
        teks += "\nKetik /pinjam untuk mengajukan peminjaman."
    else:
        if cek["jenis"] == JENIS_BARANG and hasil.sisa > 0:
            teks = (f"Stok tidak mencukupi.\n\n{cek['nama']}\nWaktu: {waktu}\n"
                    f"Sisa stok pada waktu tersebut: {hasil.sisa} unit.\n")
        else:
            teks = f"TIDAK TERSEDIA\n\n{cek['nama']} sudah dipinjam pada {waktu}.\n"
        saran = saran_waktu(hasil.bentrok)
        if saran:
            teks += f"Saran: coba setelah {format_waktu(saran)}.\n"
        teks += "\nKetik /cek untuk mencoba waktu atau item lain."

    await update.message.reply_text(teks)
    return ConversationHandler.END


def buat_handler_cek() -> ConversationHandler:
    teks = filters.TEXT & ~filters.COMMAND
    return ConversationHandler(
        entry_points=[CommandHandler("cek", mulai_cek)],
        states={
            PILIH_JENIS: [CallbackQueryHandler(pilih_jenis, pattern=r"^jenis:")],
            PILIH_ITEM: [CallbackQueryHandler(pilih_item, pattern=r"^item:")],
            ISI_WAKTU: [MessageHandler(teks, isi_waktu)],
            ISI_JUMLAH: [MessageHandler(teks, isi_jumlah)],
        },
        fallbacks=[CommandHandler("batal", batal)],
        allow_reentry=True,
    )
