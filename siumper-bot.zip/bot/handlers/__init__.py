"""Handler perintah Telegram (/cek, /pinjam, /lokasi, dan perintah umum)."""
