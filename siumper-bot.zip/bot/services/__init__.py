"""Lapisan service: akses data (Google Sheets) dan AI (Gemini)."""
