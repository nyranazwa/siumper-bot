"""Logika pengecekan ketersediaan barang/ruangan.

Sengaja dibuat tanpa ketergantungan ke Telegram/Sheets agar mudah diuji (pytest).
"""

from dataclasses import dataclass, field
from datetime import datetime

from bot.constants import FORMAT_WAKTU, JENIS_RUANGAN, STATUS_AKTIF


@dataclass
class HasilCek:
    tersedia: bool
    sisa: int
    bentrok: list[dict] = field(default_factory=list)


def waktu_bentrok(a_mulai: datetime, a_selesai: datetime,
                  b_mulai: datetime, b_selesai: datetime) -> bool:
    """Dua rentang bentrok jika saling tumpang tindih (bersentuhan di ujung tidak dihitung)."""
    return a_mulai < b_selesai and b_mulai < a_selesai


def cek_ketersediaan(jenis: str, kode: str, mulai: datetime, selesai: datetime,
                     peminjaman: list[dict], stok_total: int = 1, jumlah: int = 1) -> HasilCek:
    """Hitung sisa stok pada rentang waktu yang diminta.

    Hanya peminjaman berstatus "Menunggu Verifikasi" atau "Disetujui" yang dihitung.
    Catatan prototipe: semua peminjaman yang bentrok dijumlahkan, walaupun di antara
    mereka sendiri tidak saling tumpang tindih (perkiraan aman/konservatif).
    """
    if jenis == JENIS_RUANGAN:
        stok_total, jumlah = 1, 1

    terpakai = 0
    bentrok = []
    for row in peminjaman:
        if row.get("status") not in STATUS_AKTIF:
            continue
        if row.get("jenis") != jenis or row.get("item") != kode:
            continue
        try:
            b_mulai = datetime.strptime(row["tanggal_mulai"], FORMAT_WAKTU)
            b_selesai = datetime.strptime(row["tanggal_selesai"], FORMAT_WAKTU)
            b_jumlah = int(row.get("jumlah") or 1)
        except (KeyError, ValueError):
            continue  # baris rusak/format salah dilewati
        if waktu_bentrok(mulai, selesai, b_mulai, b_selesai):
            bentrok.append(row)
            terpakai += b_jumlah

    sisa = max(stok_total - terpakai, 0)
    return HasilCek(tersedia=sisa >= jumlah, sisa=sisa, bentrok=bentrok)


def saran_waktu(bentrok: list[dict]) -> datetime | None:
    """Saran sederhana: waktu setelah peminjaman bentrok yang paling akhir selesai."""
    akhir = []
    for row in bentrok:
        try:
            akhir.append(datetime.strptime(row["tanggal_selesai"], FORMAT_WAKTU))
        except (KeyError, ValueError):
            continue
    return max(akhir) if akhir else None
