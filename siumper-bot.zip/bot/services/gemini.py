"""Integrasi Gemini API: ekstraksi data formulir (NLP) dan pembacaan kode stiker (Vision)."""

import json
import logging

from google import genai
from google.genai import types

logger = logging.getLogger(__name__)

PROMPT_EKSTRAK = """Kamu membantu mengisi formulir peminjaman barang/ruangan kampus.
Ambil data dari pesan pengguna lalu kembalikan JSON dengan kunci:
- nama_ormawa (teks, contoh "HIMA Bisnis Digital"; perluas singkatan umum seperti "Bisdig" -> "Bisnis Digital")
- nama_kegiatan (teks)
- waktu_pinjam (format "DD-MM-YYYY HH:MM")
- waktu_kembali (format "DD-MM-YYYY HH:MM"; jika hanya jam yang disebut, pakai tanggal waktu_pinjam)
- jumlah (angka bulat)
Isi null untuk data yang tidak disebutkan. Jangan menebak.
Tahun sekarang: {tahun}. Jika tahun tidak disebut, pakai tahun sekarang.
Pertanyaan yang sedang ditanyakan bot: "{pertanyaan}"
Pesan pengguna: "{pesan}"
"""

PROMPT_STIKER = """Foto ini berisi stiker inventaris barang milik kampus.
Tuliskan HANYA kode identifikasi barang yang tertera (contoh: UPITSM-PRY-001), tanpa kalimat lain.
Jika kode tidak terlihat jelas atau foto buram, tulis: TIDAK_TERBACA"""


class GeminiService:
    def __init__(self, api_key: str, model: str):
        self._client = genai.Client(api_key=api_key)
        self._model = model

    async def ekstrak_data_peminjaman(self, pesan: str, pertanyaan: str, tahun: int) -> dict:
        """Kembalikan dict berisi field yang berhasil diekstrak. Dict kosong jika gagal."""
        prompt = PROMPT_EKSTRAK.format(tahun=tahun, pertanyaan=pertanyaan, pesan=pesan)
        try:
            resp = await self._client.aio.models.generate_content(
                model=self._model,
                contents=prompt,
                config=types.GenerateContentConfig(
                    response_mime_type="application/json",
                    temperature=0,
                ),
            )
            data = json.loads(resp.text or "{}")
        except Exception:
            logger.exception("Gemini gagal mengekstrak data")
            return {}
        if not isinstance(data, dict):
            return {}
        return {k: v for k, v in data.items() if v not in (None, "")}

    async def baca_kode_stiker(self, gambar: bytes, mime_type: str = "image/jpeg") -> str | None:
        """Baca kode inventaris dari foto stiker. None jika tidak terbaca."""
        try:
            resp = await self._client.aio.models.generate_content(
                model=self._model,
                contents=[types.Part.from_bytes(data=gambar, mime_type=mime_type), PROMPT_STIKER],
                config=types.GenerateContentConfig(temperature=0),
            )
        except Exception:
            logger.exception("Gemini Vision gagal membaca foto")
            return None
        teks = (resp.text or "").strip()
        if not teks or "TIDAK_TERBACA" in teks.upper():
            return None
        return teks.splitlines()[0].strip()
