"""Koneksi dan operasi baca/tulis ke Google Sheets (database prototipe).

Catatan: gspread bersifat sinkron (blocking). Di dalam handler bot yang async,
panggil method di sini lewat `asyncio.to_thread(...)` agar bot tidak macet.
"""

import json
import logging
import time
from typing import Any

import gspread
from gspread.exceptions import APIError, SpreadsheetNotFound, WorksheetNotFound

from bot.config import SheetsConfig
from bot.constants import (
    HEADERS,
    SHEET_BARANG,
    SHEET_DBR,
    SHEET_PEMINJAMAN,
    SHEET_RUANGAN,
)
from bot.utils.teks import normalisasi_kode

logger = logging.getLogger(__name__)

# Data master (Barang, Ruangan, DBR) jarang berubah, jadi disimpan sementara
# agar tidak cepat menghabiskan kuota Google Sheets API (±60 baca/menit).
CACHE_DETIK = 60


class SheetsError(RuntimeError):
    """Kesalahan saat mengakses Google Sheets, pesannya siap ditampilkan ke log."""


class SheetsService:
    def __init__(self, config: SheetsConfig):
        self._config = config
        self._spreadsheet: gspread.Spreadsheet | None = None
        self._cache: dict[str, tuple[float, list[dict[str, str]]]] = {}

    # ------------------------------------------------------------------
    # Koneksi
    # ------------------------------------------------------------------
    @property
    def email_service_account(self) -> str:
        """Email service account; spreadsheet harus di-share ke email ini."""
        try:
            with open(self._config.service_account_file, encoding="utf-8") as f:
                return json.load(f).get("client_email", "(tidak diketahui)")
        except (OSError, json.JSONDecodeError):
            return "(file service account tidak terbaca)"

    def _buka(self) -> gspread.Spreadsheet:
        if self._spreadsheet is not None:
            return self._spreadsheet
        try:
            client = gspread.service_account(filename=str(self._config.service_account_file))
            self._spreadsheet = client.open_by_key(self._config.spreadsheet_id)
        except SpreadsheetNotFound as e:
            raise SheetsError(
                "Spreadsheet tidak ditemukan. Pastikan SPREADSHEET_ID benar dan spreadsheet "
                f"sudah di-share (Editor) ke {self.email_service_account}."
            ) from e
        except PermissionError as e:
            raise SheetsError(
                f"Akses ditolak. Share spreadsheet (Editor) ke {self.email_service_account}."
            ) from e
        except APIError as e:
            raise SheetsError(f"Google Sheets API menolak permintaan: {e}") from e
        except (ValueError, KeyError) as e:
            raise SheetsError(f"File service account tidak valid: {e}") from e
        return self._spreadsheet

    def worksheet(self, nama: str, buat_jika_tidak_ada: bool = False) -> gspread.Worksheet:
        spreadsheet = self._buka()
        try:
            return spreadsheet.worksheet(nama)
        except WorksheetNotFound:
            if not buat_jika_tidak_ada:
                raise SheetsError(
                    f"Sheet '{nama}' tidak ada. Jalankan dulu: python -m scripts.seed_data"
                ) from None
            logger.info("Membuat sheet baru: %s", nama)
            return spreadsheet.add_worksheet(title=nama, rows=200, cols=len(HEADERS[nama]))

    # ------------------------------------------------------------------
    # Operasi umum
    # ------------------------------------------------------------------
    def ambil_semua(self, nama: str, pakai_cache: bool = False) -> list[dict[str, str]]:
        """Ambil semua baris sebagai list of dict. Semua nilai dikembalikan sebagai string."""
        if pakai_cache and nama in self._cache:
            waktu, data = self._cache[nama]
            if time.monotonic() - waktu < CACHE_DETIK:
                return data

        ws = self.worksheet(nama)
        try:
            baris = ws.get_all_records(
                expected_headers=HEADERS[nama],
                numericise_ignore=["all"],
            )
        except APIError as e:
            raise SheetsError(f"Gagal membaca sheet '{nama}': {e}") from e
        except gspread.exceptions.GSpreadException as e:
            raise SheetsError(
                f"Header sheet '{nama}' tidak sesuai. Seharusnya: {', '.join(HEADERS[nama])}"
            ) from e

        data = [{k: str(v).strip() for k, v in row.items()} for row in baris]
        self._cache[nama] = (time.monotonic(), data)
        return data

    def tambah_baris(self, nama: str, data: dict[str, Any]) -> None:
        """Tambahkan satu baris di akhir sheet sesuai urutan header."""
        nilai = [str(data.get(kolom, "")) for kolom in HEADERS[nama]]
        try:
            # RAW: simpan apa adanya sebagai teks (tanggal tidak diubah format oleh Sheets)
            self.worksheet(nama).append_row(nilai, value_input_option="RAW")
        except APIError as e:
            raise SheetsError(f"Gagal menyimpan ke sheet '{nama}': {e}") from e
        self._cache.pop(nama, None)

    def tulis_ulang(self, nama: str, baris: list[list[Any]]) -> None:
        """Hapus isi sheet lalu tulis header + baris data. Dipakai oleh seed_data."""
        ws = self.worksheet(nama, buat_jika_tidak_ada=True)
        nilai = [HEADERS[nama]] + [[str(v) for v in row] for row in baris]
        try:
            ws.clear()
            # Pastikan ukuran grid cukup; update() tidak menambah baris otomatis
            ws.resize(rows=len(nilai) + 100, cols=len(HEADERS[nama]))
            ws.update(values=nilai, range_name="A1", value_input_option="RAW")
            ws.freeze(rows=1)
        except APIError as e:
            raise SheetsError(f"Gagal menulis sheet '{nama}': {e}") from e
        self._cache.pop(nama, None)

    # ------------------------------------------------------------------
    # Operasi khusus domain SiUmper
    # ------------------------------------------------------------------
    def daftar_barang(self) -> list[dict[str, str]]:
        return self.ambil_semua(SHEET_BARANG, pakai_cache=True)

    def daftar_ruangan(self) -> list[dict[str, str]]:
        return self.ambil_semua(SHEET_RUANGAN, pakai_cache=True)

    def daftar_peminjaman(self) -> list[dict[str, str]]:
        # Tanpa cache: ketersediaan harus dihitung dari data terbaru.
        return self.ambil_semua(SHEET_PEMINJAMAN)

    def cari_dbr(self, kode: str) -> dict[str, str] | None:
        """Cari satu unit barang di DBR berdasarkan kode stiker inventaris."""
        target = normalisasi_kode(kode)
        for row in self.ambil_semua(SHEET_DBR, pakai_cache=True):
            if normalisasi_kode(row["kode_barang"]) == target:
                return row
        return None

    def simpan_peminjaman(self, data: dict[str, Any]) -> None:
        self.tambah_baris(SHEET_PEMINJAMAN, data)
